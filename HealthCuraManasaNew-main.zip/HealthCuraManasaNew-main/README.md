# HealthCuraManasa
Automation Testing project for HealthCura web app  - Edubridge Project
